const { ipcRenderer } = require('electron');

let currentTab = 0;
let tabCount = 1;

document.getElementById('search-btn').addEventListener('click', () => {
  const urlInput = document.getElementById('url-input').value;
  const webview = document.getElementById(`webview-${currentTab}`);
  if (urlInput.startsWith('http')) {
    webview.src = urlInput;
  } else {
    webview.src = `https://www.google.com/search?q=${urlInput}`;
  }
});

document.getElementById('new-tab-btn').addEventListener('click', () => {
  addTab();
});

function addTab() {
  const tabsContainer = document.getElementById('tabs');
  const webviewContainer = document.getElementById('webview-container');

  const newTab = document.createElement('div');
  newTab.className = 'tab';
  newTab.dataset.id = tabCount;
  newTab.innerText = `Aba ${tabCount + 1}`;
  newTab.onclick = () => switchTab(tabCount);
  tabsContainer.appendChild(newTab);

  const newWebview = document.createElement('webview');
  newWebview.id = `webview-${tabCount}`;
  newWebview.src = 'https://google.com';
  newWebview.style.display = 'none';
  webviewContainer.appendChild(newWebview);

  switchTab(tabCount);
  tabCount++;
}

function switchTab(tabId) {
  document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('webview').forEach(view => (view.style.display = 'none'));

  document.querySelector(`.tab[data-id="${tabId}"]`).classList.add('active');
  document.getElementById(`webview-${tabId}`).style.display = 'block';

  currentTab = tabId;
    }
